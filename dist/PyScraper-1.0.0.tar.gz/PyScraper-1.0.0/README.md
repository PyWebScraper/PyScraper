# PyScraper
**https://github.com/PyWebScraper/PyScraper/**
### How to run:

PyScraper is written and tested in Python > 3.9.13.
Although it will probably run on older Python we recommend running on 3.9.13 or newer.

Steps to get PyScraper up and running:

* Unzip to a suitable location on your computer.
* Open a terminal in the unzipped folder
* create a python virtual environment
````
> python3 -m venv venv
````
* activate the virtual environment 
````
> /venv/Scripts/activate.ps1
# or
> /venv/Scripts/activate.bat
````
If you are on unix systems
````
> source venv/bin/activate
````
* install python decencies to the virtual environment
````
(venv) > pip3 install -r rewuirements.txt
````
